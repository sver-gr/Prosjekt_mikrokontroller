/*
 * ADC_init.h
 *
 * Created: 05.05.2021 19:33:36
 *  Author: Sverre_Graffer
 */ 


#ifndef ADC_INIT_H_
#define ADC_INIT_H_

void ADC_init();
int ADC_read();

void ADC_change_pin_to_LDR();
void ADC_change_pin_to_POT();



#endif /* ADC_INIT_H_ */