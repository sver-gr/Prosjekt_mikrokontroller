/*
 * PINS.h
 *
 * Created: 06.05.2021 19:18:17
 *  Author: Sverre_Graffer
 */ 


#ifndef PINS_H_
#define PINS_H_

void PINS_init();



#endif /* PINS_H_ */