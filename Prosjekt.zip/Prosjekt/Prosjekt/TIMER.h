/*
 * TIMER_init.h
 *
 * Created: 05.05.2021 19:33:01
 *  Author: Sverre_Graffer
 */ 


#ifndef TIMER_INIT_H_
#define TIMER_INIT_H_

void reset_timer_1s_left_to_overflow();
void SERVO_set(int a);
void TIMER_init();


#endif /* TIMER_INIT_H_ */